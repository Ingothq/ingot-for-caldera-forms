ingotApp.controller( 'CFforms', [ '$scope', function ( $scope ) {
    var forms = INGOT_FORM_CF.forms;
    $scope.forms = forms;
} ] );
